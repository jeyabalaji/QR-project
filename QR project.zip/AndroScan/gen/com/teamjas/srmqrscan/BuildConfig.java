/** Automatically generated file. DO NOT MODIFY */
package com.teamjas.srmqrscan;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}